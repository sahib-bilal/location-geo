<?php

function max_sb_location_geo_settings_init() {
    
    register_setting( 'max_sb_location_geo', 'max_sb_location_geo_options' );
    register_setting( 'max_sb_location_geo_settings', 'max_sb_location_geo_settings' );
 
    max_section_design();
    max_fields_design();

    max_section_settings();
    max_fields_settings();

}
add_action( 'admin_init', 'max_sb_location_geo_settings_init' );

function max_section_design(){

    add_settings_section(
        'max_sb_location_geo_design_styling',
        __( 'Styling', 'max_sb_location_geo' ), 'max_sb_location_geo_section_styling_data',
        'max_sb_location_geo'
    );
    
}

function max_section_settings(){

    add_settings_section(
        'max_sb_location_geo_settings_neighborhood',
        __( 'Neighborhood', 'max_sb_location_geo' ), 'max_sb_location_geo_settings_neighborhood_data',
        'max_sb_location_geo_settings'
    );

    add_settings_section(
        'max_sb_location_geo_settings_activities',
        __( 'Activities', 'max_sb_location_geo' ), 'max_sb_location_geo_settings_activities_data',
        'max_sb_location_geo_settings'
    );

    add_settings_section(
        'max_sb_location_geo_settings_location',
        __( 'Location Information', 'max_sb_location_geo' ), 'max_sb_location_geo_settings_location_data',
        'max_sb_location_geo_settings'
    );

    add_settings_section(
        'max_sb_location_geo_settings_map',
        __( 'Google Map', 'max_sb_location_geo' ), 'max_sb_location_geo_settings_map_data',
        'max_sb_location_geo_settings'
    );

    add_settings_section(
        'max_sb_location_geo_settings_api',
        __( 'Google Map API', 'max_sb_location_geo' ), 'max_sb_location_geo_settings_api_data',
        'max_sb_location_geo_settings'
    );
    add_settings_section(
        'max_sb_location_geo_settings_weather_api',
        __( 'Open Weather Map Api', 'max_sb_location_geo' ), 'max_sb_location_geo_settings_weather_api_data',
        'max_sb_location_geo_settings'
    );
    
}
 

function max_sb_location_geo_settings_neighborhood_data( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>">
        <?php esc_html_e( 'This are the default options applied to all shortcodes. Defining the values directly in the shortcode will override the values define on this page.', 'max_sb_location_geo' ); ?>
    </p>
    <?php
}

function max_sb_location_geo_settings_activities_data( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>">
        <?php esc_html_e( 'This are the default options applied to all shortcodes. Defining the values directly in the shortcode will override the values define on this page.', 'max_sb_location_geo' ); ?>
    </p>
    <?php
}

function max_sb_location_geo_settings_location_data( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>">
        <?php esc_html_e( 'This are the default options applied to all shortcodes. Defining the values directly in the shortcode will override the values define on this page.', 'max_sb_location_geo' ); ?>
    </p>
    <?php
}

function max_sb_location_geo_settings_map_data( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>">
        <?php esc_html_e( 'This are the default options applied to all shortcodes. Defining the values directly in the shortcode will override the values define on this page.', 'max_sb_location_geo' ); ?>
    </p>
    <?php
}

function max_sb_location_geo_settings_api_data( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>">
        <?php esc_html_e( 'Add your google map api key.', 'max_sb_location_geo' ); ?>
    </p>
    <?php
}
function max_sb_location_geo_settings_weather_api_data( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>">
        <?php esc_html_e( 'Add your weather api key.', 'max_sb_location_geo' ); ?>
    </p>
    <?php
}

function max_sb_location_geo_section_styling_data( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>">
        <?php esc_html_e( 'This will change the appearance of each component title, paragraph and list.', 'max_sb_location_geo' ); ?>
    </p>
    <?php
}

function max_sb_location_geo_options_page() {
    add_menu_page(
        'Max Geo Location',
        'Max Geo Location',
        'manage_options',
        'max-geo-location',
        'sb_geo_location_html',
        plugins_url( 'admin/img/logo-colored.png', dirname(__FILE__) )
    );
}

add_action( 'admin_menu', 'max_sb_location_geo_options_page' );

function sb_geo_location_html() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    if ( isset( $_GET['settings-updated'] ) ) {
        add_settings_error( 'max_sb_location_geo_messages', 'max_sb_location_geo_message', __( 'Settings Saved', 'max_sb_location_geo' ), 'updated' );
    }
 
    settings_errors( 'max_sb_location_geo_messages' );

  $default_tab = null;
  $tab = isset($_GET['tab']) ? $_GET['tab'] : $default_tab;
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <nav class="nav-tab-wrapper">
            <a href="?page=max-geo-location"
                class="nav-tab <?php if($tab===null):?>nav-tab-active<?php endif; ?>">Shortcodes</a>
            <a href="?page=max-geo-location&tab=design"
                class="nav-tab <?php if($tab==='design'):?>nav-tab-active<?php endif; ?>">Design</a>
            <a href="?page=max-geo-location&tab=settings"
                class="nav-tab <?php if($tab==='settings'):?>nav-tab-active<?php endif; ?>">Settings</a>
        </nav>
        <div class="tab-content">
            <?php
                switch($tab) :
                case 'settings':
                    max_settings_tab();
                    break;
                case 'design':
                    max_design_tab();
                    break;
                default:
                max_dashboard_tab();
                    break;
                endswitch;
            ?>
        </div>
    </div>
    <?php
}
function max_design_tab(){
?>
    <form action="options.php" method="post">
        <?php
        settings_fields( 'max_sb_location_geo' );

        do_settings_sections( 'max_sb_location_geo' );

        submit_button( 'Save Settings' );
        ?>
    </form>
<?php
}

function max_settings_tab(){
    ?>
    <form action="options.php" method="post">
        <?php

            settings_fields( 'max_sb_location_geo_settings' );

            do_settings_sections( 'max_sb_location_geo_settings' );

            submit_button( 'Save Settings' );
        ?>
    </form>
    <?php
}
function max_dashboard_tab(){
    ?>
    <div class="max-sb-admin-tab">
        <h2>Shortcodes</h2>
        <h4>Details of a Location (city).</h4>
        <pre><code>[max-details title="About New York City" location="New York City, New York" limit="10"]</code></pre>
        <h4>List of Neighborhoods.</h4>
        <pre>
            <code>[max-neighborhoods title="New York" location="New York City" limit="30" sort="desc"]</code>
        </pre>
        <h4>List of Activities in a Location (city).</h4>
        <pre>
            <code>[max-activities title="Things To Do in New York" location="New York City"  limit="30" sort="desc"]</code>
        </pre>
        <h4>Google Map</h4>
        <pre>
            <code>[max-map title="" location="New York City" zoom="8" neighborhood="true" activities="true"]</code>
        </pre>
        <h4>Directions</h4>
        <pre>
            <code>[max-directions title="Max" city="New York City" address="1700 S El Camino Real #300, San Mateo, CA" pins="5"]</code>
        </pre>
        <h2>Shortcode Options</h2>
        <h3>[max-details]</h3>
        <table class="widefat striped">
            <tbody>
                <tr>
                    <th>Option name</th>
                    <th>Possible values</th>
                    <th>Default values</th>
                </tr>
                <tr>
                    <td><strong>title</strong><br /><small>Title to show above the component.</small></td>
                    <td>Any text value</td>
                    <td>Location Name</td>
                </tr>
                <tr>
                    <td><strong>location</strong><br /><small>Use city name only. Ensure that there are no whitespace
                            before<br />
                            the first letter and after the last letter.</small></td>
                    <td>Any text value</td>
                    <td>Define under settings tab</td>
                </tr>
                <tr>
                    <td><strong>limit</strong><br />Sentence limit</td>
                    <td>Number from 1 to 1000</td>
                    <td>Define under settings tab</td>
                </tr>
            </tbody>
        </table>

        <h3>[max-neighborhoods]</h3>

        <table class="widefat striped">
            <tbody>
                <tr>
                    <th>Option name</th>
                    <th>Possible values</th>
                    <th>Default values</th>
                </tr>
                <tr>
                    <td><strong>title</strong><br /><small>Title to show above the component.</small></td>
                    <td>Any text value</td>
                    <td>Location Name</td>
                </tr>
                <tr>
                    <td><strong>location</strong><br /><small>Use city name only. Ensure that there are no whitespace
                            before<br />
                            the first letter and after the last letter.</small></td>
                    <td>Any text value</td>
                    <td>Define under settings tab</td>
                </tr>
                <tr>
                    <td><strong>limit</strong><br />Limit the number of neighborhoods shown.</td>
                    <td>Number from 1 to 60</td>
                    <td>Define under settings tab</td>
                </tr>
                <tr>
                    <td><strong>sort</strong><br /><small>Arrange the list in a prescried sequence.</small></td>
                    <td>asc | desc | rand</td>
                    <td>ascending or asc</td>
                </tr>
            </tbody>
        </table>

        <h3>[max-activities]</h3>

        <table class="widefat striped">
            <tbody>
                <tr>
                    <th>Option name</th>
                    <th>Possible values</th>
                    <th>Default values</th>
                </tr>
                <tr>
                    <td><strong>title</strong><br /><small>Title to show above the component.</small></td>
                    <td>Any text value</td>
                    <td>Location Name</td>
                </tr>
                <tr>
                    <td><strong>location</strong><br /><small>Use city name only. Ensure that there are no whitespace
                            before<br />
                            the first letter and after the last letter.</small></td>
                    <td>Any text value</td>
                    <td>Define under settings tab</td>
                </tr>
                <tr>
                    <td><strong>limit</strong><br />Limit the number of activities shown.</td>
                    <td>Number from 1 to 60</td>
                    <td>Define under settings tab</td>
                </tr>
                <tr>
                    <td><strong>sort</strong><br /><small>Arrange the list in a prescried sequence.</small></td>
                    <td>asc | desc | rand</td>
                    <td>ascending or asc</td>
                </tr>
            </tbody>
        </table>

        <h3>[max-map]</h3>

        <table class="widefat striped">
            <tbody>
                <tr>
                    <th>Option name</th>
                    <th>Possible values</th>
                    <th>Default values</th>
                </tr>
                <tr>
                    <td><strong>title</strong><br /><small>Title to show above the component.</small></td>
                    <td>Any text value</td>
                    <td>none</td>
                </tr>
                <tr>
                    <td><strong>location</strong><br /><small>Use city name only. Ensure that there are no whitespace
                            before<br />
                            the first letter and after the last letter.</small></td>
                    <td>Any text value</td>
                    <td>Define under settings tab</td>
                </tr>
                <tr>
                    <td><strong>zoom</strong><br /><small>Set the zoom level from 0 (farthest) - 19 (nearest) for the
                            location.</small>
                    </td>
                    <td>Number from 0 to 19</td>
                    <td>Define under settings tab</td>
                </tr>
                <tr>
                    <td><strong>neighborhood</strong><br /><small>Set to true if you want to show the markers for each
                            neighborhood in the defined location.</small>
                    </td>
                    <td>true | false</td>
                    <td>false</td>
                </tr>
                <tr>
                    <td><strong>activities</strong><br /><small>Set to true if you want to show the markers for each
                            activities in the defined location.</small>
                    </td>
                    <td>true | false</td>
                    <td>false</td>
                </tr>
            </tbody>
        </table>

        <h3>[max-directions]</h3>

        <table class="widefat striped">
            <tbody>
                <tr>
                    <th>Option name</th>
                    <th>Possible values</th>
                    <th>Default values</th>
                </tr>
                <tr>
                    <td><strong>title</strong><br /><small>Title to show above the component.</small></td>
                    <td>Any text value</td>
                    <td>none</td>
                </tr>
                <tr>
                    <td><strong>address</strong><br /><small>Add whole address. Ensure that there are no whitespace
                            before<br />
                            the first letter and after the last letter.</small></td>
                    <td>Any text value</td>
                    <td>none</td>
                </tr>
                <tr>
                    <td><strong>city</strong><br /><small>Use city name only. Ensure that there are no whitespace
                            before<br />
                            the first letter and after the last letter.</small>
                    </td>
                    <td>Any text value</td>
                    <td>none</td>
                </tr>

                <tr>
                    <td><strong>pins</strong><br /><small>Set how many pins to show by default on load.</small></td>
                    <td>Any numbers between 1 - 10</td>
                    <td>5</td>
                </tr>

            </tbody>
        </table>

    </div>
    <?php
}